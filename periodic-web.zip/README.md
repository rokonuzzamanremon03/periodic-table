# Periodic Table Learner (EN/BN) – Netlify Ready
Static site (HTML/CSS/JS) with EN/BN language toggle, interactive table, modal details, quiz, fun facts, and mnemonics.

## Run locally
Open `index.html` in a browser, or serve with any static server.

## Deploy to Netlify
- Publish directory: `/`
- No build command needed.
